/*
 * HAL.h
 *
 *  Created on: 01.08.2010
 *      Author: Администратор
 */

#ifndef HAL_H_
#define HAL_H_

#include "stm32f10x.h"


#define F_CPU 72000000UL

//USART Config
//PORT Defines


void InitAll(void);


#endif /* HAL_H_ */
